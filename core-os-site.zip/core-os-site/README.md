# Core OS — Static Site

A minimal, production-ready landing/storefront to sell the book and link to marketplaces.

## How to deploy
- Upload the folder to Netlify/Vercel/GitHub Pages.
- Replace Stripe/Gumroad and marketplace links in `index.html`.
- Replace the Formspree endpoint in the email capture form.
- Update the canonical and share image meta tags.

## Files
- index.html — single-file site (SEO, OG, JSON-LD included)
- privacy.html, terms.html — legal stubs
- assets/
  - hf-mark.png — brand monogram
  - core-os-cover.jpg — neutral cover mock
  - avatar-*.jpg — testimonial avatars
  - logo-*.svg — retailer placeholders
  - Core-OS_Sample-Chapter.pdf — sample (included)

© 2025 Henrik Forrest. All rights reserved.
